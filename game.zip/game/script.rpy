﻿
define d = Character("Deniz", color="#7fd1ff")
define m = Character("Mailer-Daemon", color="#ff9f7f")
define k = Character("Kerem", color="#b6ff9f")

define uzun_fade = Fade(2.0, 1.0, 2.0)
define mesaj_fade = Fade(1.15, 0.5, 1.0)


image dbsup = "images/sprite female beauty spot Sur01dark.png"
image dbwor = "images/sprite female beauty spot Wor01dark.png"
image dbsad = "images/sprite female beauty spot Sad01dark.png"
image dbnormal = "images/sprite female beauty spot Smi02dark.png"

image dconf = "images/sprite female beauty spot Sur01 (1).png"
image dsad = "images/sprite female beauty spot Sad01 (1).png"
image dnormal = "images/sprite female beauty spot Smi02 (1).png"
image dwor = "images/sprite female beauty spot Wor01 (1).png"

image bg gjar3 = Transform("images/Office_BG (41).png", xysize=(config.screen_width, config.screen_height))
image bg gjar2 = Transform("images/Office_BG (24).png", xysize=(config.screen_width, config.screen_height))
image bg gjar1 = Transform("images/Office_BG (3).png", xysize=(config.screen_width, config.screen_height))
image bg gece = Transform("images/oda.png", xysize=(config.screen_width, config.screen_height))
image bg ofis = Solid("#1b2a41")
image bg gecmis = Solid("#3a2a1a")
image bg kirmizi = Solid("#401018")
image bg beyaz = Solid("#f2f2f2")
image zarf = Solid("#f5f5f5", xysize=(180, 110))
image bg kgri = Solid("#00040a")
image bg bar1 = Transform("images/barrıer1.png", xysize=(config.screen_width, config.screen_height))
image bg bar2 = Transform("images/barrıer2.png", xysize=(config.screen_width, config.screen_height))


transform sekme:
    xalign 0.5
    yalign 0.15
    easein 0.40 yalign 0.60
    easeout 0.40 yalign 0.22
    easein 0.35 yalign 0.60
    easeout 0.35 yalign 0.32
    easein 0.30 yalign 0.60
    easeout 0.30 yalign 0.42
    easein 0.25 yalign 0.60


default cesaret = 0
default durustluk = 0
default okundu1 = False
default okundu2 = False
default okundu3 = False
default gece = 1
default ilk_baslangic = True


label start:

    scene bg gece with fade

    "03:12."
    "Laptopun ekranı odadaki tek ışık."

    show dbnormal at right with fade
    d "Üç yıl. Üç yıl sonra Kerem'e ilk kez yazıyorum."

    show dbsup at right
    "Boş bir e-posta. İmleç yanıp sönüyor."
    "Yazmak istediğimden emin değilim."
    "..."

    menu:
        "İlk cümle nasıl olsun?"

        "\"Özür dilerim.\"":
            show dbwor at right
            $ cesaret += 1
            $ durustluk += 1
            d "Doğrusu bu. Başka türlüsü yalan olur."

        "\"Nasılsın? Uzun zaman oldu.\"":
            show dbnormal at right
            d "Hafif başlayalım. Ağır şeyler sonra gelir."

    d "Gönder'e basıyorum."

    jump Yazılar


label Yazılar:

    scene bg kgri with fade
    show zarf at sekme

    "Zarf ekrandan fırlar... ve geri döner."
    with vpunch

    jump Devam


label Devam:

    scene bg gece with fade

    "{b}Mesaj teslim edilemedi.{/b}"
    "Zarf üç kez sekip tam önünde durur."

    show dbsup at right with fade
    d "Yine mi? Adres mi değişmiş..."

    m "Adres değişti, evet. Ama bu ilk sekme değil."

    show dbwor at right
    d "Kim konuşuyor?"

    m "Ben Mailer-Daemon. Sana geri dönen şeylerin kapısıyım."
    m "Seninle yalnız şunu paylaşacağım: Uzun zamandır çekmecemde senin adına bekleyen üç mesaj var."

    show dbnormal at right
    d "Benim adıma bekleyen mesaj mı? İyi de ben hiçbir şey yazmadım."

    m "Haklısın. Onları sana başkası yazdı."

    jump taslaklar


label taslaklar:

    if okundu1 and okundu2 and okundu3:
        jump ifsa

    scene bg bar1 with uzun_fade

    show dnormal at right

    m "Önce hangi mesajı açmak istersin?"

    show dconf at right
    d "Okumak istediğimden emin değilim..."

    m "O zaman neden her gece buradasın?"

    show dnormal at right
    d "Ne demek istiyorsun?"

    m "Açıklayacağım."

    menu:

        "Birinci mesaj: \"Demo günü\"" if not okundu1:
            jump mesaj1

        "İkinci mesaj: \"Son sahne\"" if not okundu2:
            jump mesaj2

        "Üçüncü mesaj: \"Yeni adres\"" if not okundu3:
            jump mesaj3


label mesaj1:

    scene bg bar2 with dissolve
    show dbsad at right

    "{b}Kimden:{/b} Kerem\n{b}Konu:{/b} Demo günü\n{b}Tarih:{/b} 3 yıl önce"

    k "Deniz nerelerdesin?? Game Jam sunumlarının başlamasına çok az kaldı ama ulaşılamıyorsun??.. yine."
    k "Direkt telefonun kapalıydı. Biraz tepki gösterdim. Belki de korkmuştun? Ne olduğuna anlam veremiyorum.."
    k "Oyunu bütün zaman boyunca birlikte geliştirmiştik, anlayamıyorum. Sadece sunum kalmıştı. Ancak yine de kapıyı açık bırakıyorum."

    $ okundu1 = True

    menu:

        "Mesaja nasıl tepki veriyorsun?"

        "Sonuna kadar oku, gözlerini kaçırma":
            show dbnormal at right with fade
            $ cesaret += 1
            d "Aslında kırgın, ancak belli etmiyor."

        "Ekranı çevir, okuyamıyorum":
            show dbsup at right with fade
            d "Yeter. Kapat bunu."
            m "Kapatsan da ben tutuyorum."

    jump taslaklar


label mesaj2:

    scene bg bar2 with dissolve
    show dbsad at right

    "{b}Kimden:{/b} Kerem\n{b}Konu:{/b} Son sahne\n{b}Tarih:{/b} 2 yıl önce"

    k "Oyunu çıkardım. Adını \"Sekme\" koydum, hatırlıyorsun, senin fikrindi."
    k "Son sahneyi sen yazmıştın. Silmedim. Kredilerde adın var."
    k "Bunu neden sana yazıyorum bilmiyorum. Mesaj sana ulaşmayacak bile. Ama gönderiyorum nedense?"

    $ okundu2 = True

    menu:

        "Mesaja nasıl tepki veriyorsun?"

        "Sonuna kadar oku, gözlerini kaçırma":
            show dbsad at right
            $ cesaret += 1
            $ durustluk += 1
            d "Adım duruyormuş. Ben ise kaçmıştım."

        "Ekranı çevir, okuyamıyorum":
            show dbsup at right
            d "Neden hâlâ nazik? Hak etmiyorum."
            m "Bunu o seçmiş, sen değil."

    jump taslaklar


label mesaj3:

    scene bg bar2 with dissolve
    show dbsad at right

    "{b}Kimden:{/b} Kerem\n{b}Konu:{/b} Yeni adres\n{b}Tarih:{/b} Geçen hafta"

    k "Eski adresimi kapattım. Yeni adresim: kerem@sekme.example"
    k "Yazmana gerek yok. Ama yazarsan, bu sefer sekmez."
    k "Çünkü ben hâlâ buradayım."

    $ okundu3 = True

    menu:

        "Mesaja nasıl tepki veriyorsun?"

        "Sonuna kadar oku, gözlerini kaçırma":
            show dbsad at right
            d "Bu sefer sekmeyecek."

        "Ekranı çevir, okuyamıyorum":
            show dbsup at right
            d "Çok geç oldu."
            m "Gece 3'ü on iki geçe hep aynı cümleyi kuruyorsun."

    jump taslaklar


label ifsa:

    scene bg gece with mesaj_fade

    "Ekrandaki bütün mesajlar bir anlığına kaybolur."

    m "Şimdi sana bir şey anlatmam gerekiyor."
    m "Bu gece, bin doksan altıncı gece."

    show dbsup at right
    d "Ne demek bin doksan altıncı gece?"

    $ gece = 1096

    m "Her gece saat 03:12'de bu bilgisayarı açıyorsun."
    m "Aynı e-postayı yazıyorsun. Aynı adrese gönderiyorsun."
    m "Ve her seferinde aynı hatayı alıyorsun."

    show dbwor at right
    d "Ben bunu daha önce yapmadım."

    m "Üç yıldır aynı şeyi söylüyorsun."

    "Odanın duvarında yüzlerce küçük çizik belirir."

    show dbnormal at right
    d "Bunlar ne?"

    m "Kaçtığın her gece."

    show dbwor at right
    d "Sen kimsin? Bütün bunları nereden biliyorsun?"

    m "Çünkü ben senin bilgisayarındaki eski posta kutusuyum."

    show dbnormal at right
    m "Üç yıldır açmadığın, silmeye cesaret edemediğin mesajlar."

    show dbsad at right
    m "Bana bir isim verdin. Mailer-Daemon."

    d "Yani sen gerçek değilsin?"

    m "Peki, sence bu mesajlar gerçek değil mi?"

    scene bg gjar1 with uzun_fade

    "Ekranda eski bir fotoğraf belirir."

    show dwor at right
    d "Bu... demo günü."

    m "Hatırladın mı?"
    d "Oyunu birlikte yapmıştık."
    d "Her şey hazırdı. Sadece sunum kalmıştı."

    show dsad at right
    m "Ama sen gelmedin."

    scene bg gjar2 with fade

    show dbwor at right
    d "Korkmuştum."
    d "Ya oyun çalışmazsa? Ya herkesin önünde rezil olursak?"

    show dbsad at right
    d "Kerem'in bütün emeğini boşa çıkarmaktan korktum."

    m "Kerem yine de oyunu sundu."
    m "Oyunu tamamladı."
    show dbwor at right
    m "Ve senin adını kredilerden silmedi."
    d "Ben ise tek bir mesaj bile atmadım."
    show dbsad at right
    m "İşte bu yüzden buradayız."

    scene bg gjar3 with fade
    show dbnormal at right
    d "Peki ya bu üç mesaj?"

    m "Kerem'in sana ulaşmak için gönderdiği mesajlar."
    m "İlkinde seni bekledi."
    show dbwor at right
    m "İkincisinde oyunu bitirdi."
    m "Üçüncüsünde ise yeni adresini bıraktı."
    show dbsad at right

    d "Bunca zaman... Benim onu aramamı mı bekledi?"

    m "Bunu yalnızca ona sorabilirsin."

    scene bg gece with mesaj_fade

    d "Peki sen neden her gece buradasın?"
    show dbnormal at right
    m "Çünkü her seferinde vazgeçtiğinde beni yeniden açıyorsun."
    show dbsup at right
    m "Ben senin geri dönen tarafınım."
    m "Ama geri dönmek için aynı yerde beklemek yetmez."
    show dbsad at right

    "Laptopun ekranında yeni bir e-posta penceresi açılır."
    show dbnormal at right

    m "Bu sefer ne yapacaksın?"

    menu:

        "Laptopu kapat":
            jump son_dongu

        "Kerem'in yeni adresine yaz":
            jump son_mail

        "Telefonu al ve ara" if cesaret >= 2:
            jump son_telefon


label son_dongu:

    scene bg bar2 with fade

    "Deniz uzun süre ekrana bakar."
    show dbsad at right

    d "Henüz hazır değilim."
    show dbwor at right

    m "Biliyorum."

    "Laptopun kapağı kapanır."
    show dbsad at right

    m "Ama artık neyi beklediğini biliyorsun."

    "03:12."

    $ gece += 1

    jump start


label son_mail:

    scene bg gece with fade
    show dbsup at right

    d "Yeni adres. Bu sefer sekmeyecek."
    show dbnormal at right

    if durustluk >= 2:
        d "\"Özür dilerim. Üç yıl geç kaldım. Oyunun sonunu okumak istiyorum.\""
    else:
        d "\"Merhaba Kerem. Mesajlarını okudum. Konuşabilir miyiz?\""

    "Gönder."
    "{b}Teslim edildi.{/b}"

    m "İlk kez sekmedi."
    show dbsup at right

    d "Cevap verir mi?"

    m "Bilmiyorum. Ama sen yazdın. Bu da bir geri dönüş."

    scene bg beyaz with fade

    "Sabah 07:40. Yeni mesaj: 1."
    k "\"Geç kaldın. Kahve senden.\""

    "SON: Teslim Edildi"

    return


label son_telefon:

    scene bg gece with fade

    d "Mesaj değil. Bu sefer sesim."
    show dbsup at right

    "---Telefon üç kez çalar."

    show dbnormal at right
    k "...Deniz? Saat üçü geçti."
    show dbsup at right
    d "Biliyorum. Üç yıl geç kaldım."
    k "Üç yıl ve on iki dakika."
    show dbsad at right
    d "Özür dilerim, Kerem."
    k "Dinliyorum. Ama önce şunu söyle: Sekme'nin devamını yazalım mı?"
    "..."

    scene bg beyaz with fade

    "Ekranda yazı belirir:"

    "{size=+20}{b}SEKME{/b}{/size}\nKerem & Deniz"

    "Az önce oynadığın oyun, onların birlikte bitirdiği oyundu."

    m "Düşmek sorun değildi. Sekmeyi unutmak sorundu."

    "SON: Sekme"

    return

